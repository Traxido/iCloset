//
//  HomeViewController.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/14/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var items: [Item] = []
    var newClothes: [Item] = []
    
    var city: String? = "Fort%20Wayne"
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var degreeLbl: UILabel!
    @IBOutlet weak var conditionLbl: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    
    var exists: Bool? = true
    var degree: Int = 0
    var condition: String? = ""
    var imgURL: String? = ""
    
    @IBOutlet weak var userProfilePicture: UIButton!
    var currentClothes: [String?] = [""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userProfilePicture.layer.masksToBounds = true
        
        
        //weather
        let urlRequest = URLRequest(url: URL(string: "http://api.apixu.com/v1/current.json?key=e4830d52861f40068ed03904171908&q=\(city!.replacingOccurrences(of: " ", with: "%20"))")!)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil {
                do {
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String : AnyObject]
                    
                    if let current = json["current"] as? [String : AnyObject] {
                        
                        if let temp = current["temp_f"] as? Int {
                            self.degree = temp
                        }
                        if let condition = current["condition"] as? [String : AnyObject] {
                            self.condition = condition["text"] as? String
                            let icon = condition["icon"] as! String
                            self.imgURL = "http:\(icon)"
                        }
                    }
                    if let location = json["location"] as? [String : AnyObject] {
                        self.city = location["name"] as? String
                    }
                    
                    if let _ = json["error"] {
                        self.exists = false
                    }
                    
                    DispatchQueue.main.async {
                        if self.exists!{
                            self.degreeLbl.isHidden = false
                            self.conditionLbl.isHidden = false
                            self.imgView.isHidden = false
                            self.degreeLbl.text = "\(self.degree)°"
                            self.conditionLbl.text = self.condition
                            self.imgView.downloadImage(from: self.imgURL!)
                        }else {
                            print("fail")
                        }
                    }
                    
                    
                } catch let jsonError {
                    print(jsonError.localizedDescription)
                }
            }
        }
        
        task.resume()
        
        
        
        
    }

    
    
    //Number of views
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return newClothes.count
    }
    
    //Populate view
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "clothess", for: indexPath) as! ClothesCollectionViewCell
        
        DispatchQueue.main.async(execute: { () -> Void in
            
        let item = self.newClothes[indexPath.row]
            
            cell.name.text = item.title
            if let imageData = item.image {
                
                cell.image?.image = UIImage(data: imageData as Data)
                
            }
            if item.color == "Red" {
            cell.colorView.backgroundColor = UIColor.red
            } else if item.color == "Orange" {
            cell.colorView.backgroundColor = UIColor.orange
            } else if item.color == "Yellow" {
                cell.colorView.backgroundColor = UIColor.yellow
            } else if item.color == "Green" {
                cell.colorView.backgroundColor = UIColor.green
            } else if item.color == "Blue" {
                cell.colorView.backgroundColor = UIColor.blue
            } else if item.color == "Purple" {
                cell.colorView.backgroundColor = UIColor.purple
            }
            
            
            
        })
    
    
        
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getItems()
        getClothes()
        collectionView?.reloadData()
    }
    
    func getClothes() {
        
        if items.count > 0 {
        
        
        
        
        /*
            let shirtArray = items.filter { $0 .type == "Shirt" }
            let randomShirt = Int(arc4random_uniform(UInt32(shirtArray.count)))

            let pantsArray = items.filter { $0 .type == "Pants"}
            let randomPants = Int(arc4random_uniform(UInt32(pantsArray.count)))
            
            let shoesArray = items.filter { $0 .type == "Shoes" }
            let randomShoes = Int(arc4random_uniform(UInt32(shoesArray.count)))
            
            newClothes.append(shirtArray[randomShirt])
            newClothes.append(pantsArray[randomPants])
            newClothes.append(shoesArray[randomShoes])
 */
            
 
        }
    }
    
    func getItems() {
        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            
            if let coreDataStuff = try? context.fetch(Item.fetchRequest()) as? [Item] {
                if let coreDataItems = coreDataStuff {
                    items = coreDataItems
                    collectionView?.reloadData()
                }
            }
            
        }
    }
    
    
    @IBAction func userSettings(_ sender: Any) {
        let MainStoryboard:UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let userView = MainStoryboard.instantiateViewController(withIdentifier: "UserViewController") as! UserViewController
        self.navigationController?.pushViewController(userView, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIImageView {
    
    func downloadImage(from url: String) {
        let urlRequest = URLRequest(url: URL(string: url)!)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil {
                DispatchQueue.main.async {
                    self.image = UIImage(data: data!)
                }
            }
        }
        task.resume()
}
}
