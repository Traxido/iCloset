//
//  CameraViewController.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/14/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var taken: Bool? = nil
    
    @IBOutlet weak var infoView: UIView!
    
    @IBOutlet weak var temperatureIcon: UILabel!
    
    @IBOutlet weak var temperatureSlider: UISlider!
    @IBOutlet weak var whichPicker: UIView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var pictureUIView: UIView!
    @IBOutlet weak var colorPicker: UIPickerView!
    @IBOutlet weak var colorPickerButton: UIButton!
    @IBOutlet weak var typePicker: UISegmentedControl!
    @IBOutlet weak var itemTitle: UITextField!
    @IBOutlet weak var itemDescription: UITextField!
    @IBOutlet weak var pickedColor: UILabel!
    
    var color: [String] = ["Red", "Orange", "Yellow", "Green", "Blue", "Purple"]
    var imagePicker = UIImagePickerController()
    var typePicked: String = ""
    
    @IBAction func addImage(_ sender: Any) {
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
        taken = true
    }
    
    @IBAction func chooseImage(_ sender: Any) {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
        taken = false
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            image.image = chosenImage
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
        whichPicker.isHidden = true
        
        
    }
    
    
    @IBAction func temperatureSlide(_ sender: UISlider) {
        if sender.value <= 25 {
            temperatureIcon.text = "❄️"
        } else if sender.value > 25 && sender.value <= 50 {
            temperatureIcon.text = "⛅️"
        } else if sender.value > 50 && sender.value <= 75 {
            temperatureIcon.text = "☀️"
        } else if sender.value > 75 {
            temperatureIcon.text = "🔥"
        }
    }
    
    
    
    @IBAction func closeInfoView(_ sender: Any) {
        infoView.isHidden = true
    }
    
    
    @IBAction func temperatureInfo(_ sender: Any) {
        infoView.isHidden = false
    }
    
    
    @IBAction func toggleType(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            typePicked = "Hats"
        } else if sender.selectedSegmentIndex == 1 {
            typePicked = "Shirts"
        } else if sender.selectedSegmentIndex == 2 {
            typePicked = "Pants"
        } else if sender.selectedSegmentIndex == 3 {
            typePicked = "Shoes"
        } else if sender.selectedSegmentIndex == 4 {
            typePicked = "Other"
        }
    }
    
    func resetViewController() {
        itemTitle.text = ""
        itemDescription.text = ""
        pickedColor.text = "Red"
        pickedColor.textColor = UIColor.white
        typePicker.selectedSegmentIndex = 0
        image.image = nil
        colorPickerButton.backgroundColor = UIColor(red:0.99, green:0.26, blue:0.39, alpha:1.0)
        whichPicker.isHidden = false
    }
    
    
    @IBAction func chooseColor(_ sender: Any) {
        colorPicker.isHidden = false
    }
    
    func imageResize (image:UIImage, sizeChange:CGSize)-> UIImage{
        
        let hasAlpha = true
        let scale: CGFloat = 0.0 // Use scale factor of main screen
        
        UIGraphicsBeginImageContextWithOptions(sizeChange, !hasAlpha, scale)
        image.draw(in: CGRect(origin: CGPoint.zero, size: sizeChange))
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        return scaledImage!
    }
    
    let size = CGSize.init(width: 100, height: 150)
    
    
    @IBAction func addClothingItem(_ sender: Any) {
        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            whichPicker.isHidden = true
            let item = Item(entity: Item.entity(), insertInto: context)
            item.title = itemTitle.text
            item.itemDescription = itemDescription.text
            item.color = pickedColor.text
            item.type = typePicked
            item.temp = temperatureIcon.text
            image.image = imageResize(image: image.image!, sizeChange: size)
            if let image = image.image {
                if let imageData = UIImagePNGRepresentation(image) {
                    item.image = imageData as NSData
                }
            }
            
            try? context.save()
            resetViewController()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        pictureUIView.layer.masksToBounds = true
        

        // Do any additional setup after loading the view.
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return color.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return color[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickedColor.text = color[row]
        colorPicker.isHidden = true
        if color[row] == "Red" {
        colorPickerButton.backgroundColor = UIColor.red
            pickedColor.textColor = UIColor.white
        } else if color[row] == "Orange" {
            colorPickerButton.backgroundColor = UIColor.orange
            pickedColor.textColor = UIColor.white
        } else if color[row] == "Yellow" {
            colorPickerButton.backgroundColor = UIColor.yellow
            pickedColor.textColor = UIColor.black
        } else if color[row] == "Green" {
            colorPickerButton.backgroundColor = UIColor.green
            pickedColor.textColor = UIColor.black
        } else if color[row] == "Blue" {
            colorPickerButton.backgroundColor = UIColor.blue
            pickedColor.textColor = UIColor.white
        } else if color[row] == "Purple" {
            colorPickerButton.backgroundColor = UIColor.purple
            pickedColor.textColor = UIColor.white
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
