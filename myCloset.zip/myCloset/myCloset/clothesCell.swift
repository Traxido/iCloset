//
//  clothesCell.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/15/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class clothesCell: UICollectionViewCell {
    
    @IBOutlet var image: UIImageView!
    @IBOutlet weak var itemTitle: UILabel!
    
}
