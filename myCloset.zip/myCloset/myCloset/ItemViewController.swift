//
//  ItemViewController.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/16/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class ItemViewController: UIViewController {
    
    var getTitle = String()
    var getImage = Data()
    var getDescription = String()
    var getColor = String()
    var getType = String()
    var getTemp = String()
    
    var itemColorStr = String()
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemTitle: UILabel!
    @IBOutlet weak var itemDescription: UITextView!
    @IBOutlet weak var itemType: UILabel!
    @IBOutlet weak var itemColor: UIView!
    @IBOutlet weak var itemTemp: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        itemTitle.text = getTitle
        let imageData = getImage
        itemImage.image = UIImage(data: imageData as Data)
        itemDescription.text = getDescription
        itemType.text = getType
        if getColor == "Red" {
            itemColor.backgroundColor = UIColor.red
        } else if getColor == "Orange" {
            self.itemColor.backgroundColor = UIColor.orange
        } else if getColor == "Yellow" {
            self.itemColor.backgroundColor = UIColor.yellow
        } else if getColor == "Green" {
            self.itemColor.backgroundColor = UIColor.green
        } else if getColor == "Blue" {
            self.itemColor.backgroundColor = UIColor.blue
        } else if getColor == "Purple" {
            self.itemColor.backgroundColor = UIColor.purple
        }
        itemTemp.text = getTemp
        
        print("working")
        
        
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
