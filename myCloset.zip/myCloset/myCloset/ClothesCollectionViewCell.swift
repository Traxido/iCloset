//
//  ClothesCollectionViewCell.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/18/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class ClothesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var name: UILabel!
    
    
}
