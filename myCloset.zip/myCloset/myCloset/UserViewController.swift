//
//  UserViewController.swift
//  myCloset
//
//  Created by ANDREW-MAC on 8/14/17.
//  Copyright © 2017 ANDREW-MAC. All rights reserved.
//

import UIKit

class UserViewController: UIViewController {
    
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    



}
